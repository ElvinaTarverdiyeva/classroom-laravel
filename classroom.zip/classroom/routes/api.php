<?php

use App\Http\Controllers\auth\AuthController;
use App\Http\Controllers\BlogContoller;
use App\Http\Controllers\TypeContoller;
use App\Http\Controllers\UserContoller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('v1')->group(function () {
    Route::post('register', [UserContoller::class, 'store']);
    Route::post('login', [AuthController::class, 'login']);
    Route::group(['middleware' => ['auth:sanctum']], function () {
        Route::resource('user', UserController::class);
        Route::get('login-user', [UserController::class, 'getLoggedInUser']);
        Route::post('logOut', [AuthController::class, 'logOut']);

        Route::resource('blog', BlogContoller::class);
        Route::resource('type', TypeContoller::class);
    });
});
